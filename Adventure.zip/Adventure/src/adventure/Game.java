package adventure;


import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import static javafx.scene.text.Font.font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 212728290
 */
public class Game {
    
    JFrame window;
    Container con;
    JPanel titleNamePanel;
    JLabel titleNameLabel;
    Font titlefont = new Font("Times New Roman", Font.PLAIN, 46);
    
    
    public static void main(String[] args) {
        new Game();
    }
    
    public Game(){
        //Window creation
        window = new JFrame();
        window.setSize(800, 600);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().setBackground(Color.BLACK);
        window.setLayout(null);
        window.setVisible(true);
        con = window.getContentPane();
        
        //Title Panel with title label
        titleNamePanel = new JPanel();
        titleNamePanel.setBounds(100,100,600,150);
        titleNamePanel.setBackground(Color.BLACK);
        titleNameLabel = new JLabel("3621 - A VÉDŐK"); //Main title
        titleNameLabel.setForeground(Color.MAGENTA);
        titleNameLabel.setFont(titlefont);
        titleNamePanel.add(titleNameLabel);
        titleNameLabel.setVisible(true);
        con.add(titleNamePanel);
        
        
        //https://www.youtube.com/watch?v=RcvABhflOkI
        
    }
}
